#!/usr/bin/env python3

import torch
import numpy as np
import argparse

import torch
import cv2
from multiprocessing import Process, Queue

import requests

from picamera2 import MappedArray, Picamera2
from picamera2.devices import IMX500
import psutil

from cloud_to_edge import ServerToEdge
from edge_to_cloud import EdgeToServer


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", '-m', type=str, default="./yoloe_gussian_50.rpk")
    return parser.parse_args()


last_detections = []

class Detection:
    def __init__(self, box, category, conf):
        """Create a Detection object, recording the bounding box, category and confidence."""
        self.category = category
        self.conf = conf
        self.box = box


def send_inference_results(server_url, client_id, q2):
    e2s = EdgeToServer(server_url, client_id)
    e2s.send_event(q2)



def draw_detections(request, last_results, prompts_list, stream="main"):
    """Draw the detections for this request onto the ISP output."""
    if last_results is None:
        return
    with MappedArray(request, stream) as m:
        for detection in last_results:
            y_min, x_min, y_max, x_max = detection.box

            x = int(x_min)
            y = int(y_min)
            h = int(y_max - y_min)
            w = int(x_max - x_min)

            try:
                label = f"{prompts_list[int(detection.category)]} ({detection.conf:.2f})"
            except IndexError:
                continue

            font_scale = 1.0
            thickness = 2

            # Calculate text size and position
            (text_width, text_height), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
            text_x = x + 15
            text_y = y + 25

            # Create a copy of the array to draw the background with opacity
            overlay = m.array.copy()          

            # Draw the background rectangle on the overlay
            cv2.rectangle(overlay,
                        (text_x, text_y - text_height),
                        (text_x + text_width, text_y + baseline),
                        (255, 255, 255),  # Background color (white)
                        cv2.FILLED)

            alpha = 0.30
            cv2.addWeighted(overlay, alpha, m.array, 1 - alpha, 0, m.array)

            # Draw text on top of the background
            cv2.putText(m.array, label, (text_x, text_y),
                        cv2.FONT_HERSHEY_SIMPLEX, font_scale, (0, 0, 255), 1)

            # Draw detection box
            cv2.rectangle(m.array, (x, y), (x + w, y + h), (0, 255, 0, 0), thickness=thickness)


def post_process(nms_indices, nms_boxes, cls_pe, raw_cls, num_proposals, strides, bias, scale, 
                 orig_height, orig_width, nc, threshold, new_height=416, new_width=416):
    
    boxes_cls, scores_cls = [], []
    for k in range(len(strides)):
        if k == 0:
            idx = torch.where(nms_indices < strides[0] ** 2)
        elif k == 1:
            idx = torch.where((strides[0] ** 2 <= nms_indices) & (nms_indices < (strides[0] ** 2 + strides[1] ** 2)))
        else:
            idx = torch.where((strides[0] ** 2 + strides[1] ** 2) <= nms_indices)
        raw_cls_k = raw_cls[0, :, idx[0]].unsqueeze(0)
        clsk = torch.sigmoid(scale[k] * torch.matmul(cls_pe, raw_cls_k) + bias[k])
        scores_cls.append(clsk)
        boxes_clsk = nms_boxes[0, idx[0], :]
        boxes_cls.append(boxes_clsk)
    cls = torch.cat(scores_cls, dim=2).reshape(nc, 1, -1).permute(1, 0, 2)
    scores, classes = torch.max(cls, dim=1)

    boxes = torch.cat(boxes_cls, dim=0).reshape(1, -1, 4)

    # Torch to numpy
    boxes = boxes.detach().cpu().contiguous().numpy()
    scores = scores.detach().cpu().contiguous().numpy()
    classes = classes.detach().cpu().contiguous().numpy()

    idx = np.argsort(scores)[0,::-1][:int(num_proposals)]
    scores = scores[0,idx]
    boxes = boxes[0,idx,:]
    classes = classes[0,idx]

    # Filter threshold
    mask = np.where(scores > threshold)

    boxes = boxes[mask]
    scores = scores[mask]
    classes = classes[mask]

    # No aspect ratio preserving
    scale_H = orig_height / new_height
    scale_W = orig_width / new_width
    deltaH, deltaW = 0, 0

    boxes[..., [0, 1, 2, 3]] = boxes[..., [1, 0, 3, 2]]
    boxes[..., 0] = (boxes[..., 0] - deltaH) * scale_H
    boxes[..., 1] = (boxes[..., 1] - deltaW) * scale_W
    boxes[..., 2] = (boxes[..., 2] - deltaH) * scale_H
    boxes[..., 3] = (boxes[..., 3] - deltaW) * scale_W

    # Clip boxes
    boxes[..., 0] = np.clip(boxes[..., 0], a_min=0, a_max=orig_height)
    boxes[..., 1] = np.clip(boxes[..., 1], a_min=0, a_max=orig_width)
    boxes[..., 2] = np.clip(boxes[..., 2], a_min=0, a_max=orig_height)
    boxes[..., 3] = np.clip(boxes[..., 3], a_min=0, a_max=orig_width)

    last_detections = [
        Detection(box, category, score)
        for box, score, category in zip(boxes, scores, classes)
    ]

    return last_detections


def run_camera_inference(q1, q2):
    args = get_args()
    global imx500, picam2
    imx500 = IMX500(args.model)
    imx500.set_inference_aspect_ratio(imx500.get_input_size())
    picam2 = Picamera2(imx500.camera_num)

    orig_width, orig_height = 832, 832

    main = {"format": "XBGR8888", "size": (orig_width, orig_height), "preserve_ar": True}
    config = picam2.create_preview_configuration(controls={"FrameRate": 15}, buffer_count=4, main=main)

    imx500.show_network_fw_progress_bar()

    strides = [52, 26, 13] #chs
    bias = [-14.0703125, -13.328125, -12.46875]
    scale = [0.9141297936439514, 0.9272226691246033, 1.088342308998108]

    prompts_list, embeddings_only, index_to_promptid, threshold = q1.get()
    nc = embeddings_only.shape[1]

    print("Got first text embeddings!")

    picam2.start(config, show_preview=True)

    last_results = []

    picam2.pre_callback = lambda request: draw_detections(request, last_results, prompts_list)

    while True:
        try:
            prompts_list, embeddings_only, index_to_promptid, threshold = q1.get(timeout=0.001)  # waits up to 1 mili
            nc = embeddings_only.shape[1]
        except Exception:
            pass
        
        metadata = picam2.capture_metadata()
        np_outputs = imx500.get_outputs(metadata, add_batch=True)

        input_w, input_h = imx500.get_input_size()
        nms_boxes, nms_indices, num_proposals, raw_cls = torch.tensor(np_outputs[0]), torch.tensor(np_outputs[1][0]), np_outputs[2][0], torch.tensor(np_outputs[3])
        
        last_results = post_process(nms_indices, nms_boxes, embeddings_only, raw_cls, 
                                    num_proposals, strides, bias, scale, orig_height, orig_width, nc, threshold, 
                                    new_height=input_h, new_width=input_w)
        
        q2.put((last_results, index_to_promptid, prompts_list))


def revc_text_embeddings(server_url, client_id, last_seen, q1):
    s2e = ServerToEdge(server_url, client_id, last_seen)
    s2e.run_client(q1)


def get_mac_address(interface='wlan0'):
    addrs = psutil.net_if_addrs()
    if interface in addrs:
        for snic in addrs[interface]:
            if snic.family.name == 'AF_LINK' or snic.family == psutil.AF_LINK:
                return str(snic.address)
    return None


def main():

    SERVER_URL = "https://edge-be.ssi-tools.com/api/"
    MAC_ADDRESS = get_mac_address('wlan0')
    headers = {"content-type" : "application/json"}
    post_json = {"macAddress": MAC_ADDRESS}

    response_json = requests.post(f"{SERVER_URL}env/device/add", json=post_json, headers=headers).json()
    cloud_device_id = response_json["id"]
    last_seen = None

    q1 = Queue()
    q2 = Queue()

    p1 = Process(target=revc_text_embeddings, args=(f"{SERVER_URL}case/updates", cloud_device_id, last_seen, q1))
    p2 = Process(target=run_camera_inference, args=(q1, q2))
    p3 = Process(target=send_inference_results, args=(f"{SERVER_URL}case/event", cloud_device_id, q2))

    p1.start()
    p2.start()
    p3.start()

    p1.join()
    p2.join()
    p3.join()

if __name__ == "__main__":
    main()