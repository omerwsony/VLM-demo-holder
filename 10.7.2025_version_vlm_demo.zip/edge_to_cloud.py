import requests


class EdgeToServer:
    def __init__(self, server_url, client_id):
        self.server_url = server_url
        self.id = client_id

    def send_event(self, q):
        while True:
            inference_results, index_to_promptid, prompts_list = q.get()
            promptid_to_detections = []
            for detection in inference_results:
                box = detection.box
                score = detection.conf
                cls = detection.category

                try:
                    class_name = prompts_list[cls]
                    promptid_to_detections.append({"promptId" : index_to_promptid[cls], "bbox" : [float(x) for x in box], "score" : float(score), "className" : class_name})
                except IndexError:
                    continue
            
            event_data = {'detections' : promptid_to_detections}

            # response = requests.post(self.server_url, json=event_data)
            # print("Event send response:", response.json())