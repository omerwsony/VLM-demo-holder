import requests
import torch
import time


class ServerToEdge:
    def __init__(self, server_url, client_id, last_seen):
        self.server_url = server_url
        self.id = client_id
        self.seen = last_seen


    def check_for_updates(self):
        response = requests.put(self.server_url, json={"deviceId": self.id, "lastUpdate" : self.seen})
        return response.json()
    

    def run_client(self, q):
        while True:
            response = self.check_for_updates()
            self.seen = response['updatedAt']
            if response['changes'] and response['prompts']:
                prompts_list = []
                index_to_promptid = {}
                embeddings_only = []
                for i, prompt in enumerate(response['prompts']):
                    text = prompt['raw']
                    promptid = prompt['id']
                    embeddings = torch.tensor(eval(prompt['encoded'])) # 1x512
                    
                    prompts_list.append(text)

                    embeddings_only.append(embeddings)
                    index_to_promptid[i] = str(promptid)

                threshold = float(response['settings']['threshold'])
                stacked = torch.stack([t.squeeze(0) for t in embeddings_only])
                q.put((prompts_list, stacked.unsqueeze(0), index_to_promptid, threshold))
            time.sleep(1)


    # def check_for_updates(self):
    #     import numpy as np
    #     # data = np.load('./from_database.npy')[0]
    #     # texts = ["bus", "table", "book", "cake", "person"]
    #     data = np.load('/home/jojo/vlm_demo/VLM-demo/from_database.npy')[0]
    #     # texts = ["book", "bus", "table", "cake", "person"]
    #     texts = ["person", "bus", "book"]
    #     response_list = []
    #     for i in range(len(texts)):
    #         js = {}
    #         js["id"] = i
    #         js["raw"] = texts[i]
    #         js["encoded"] = data[i]
    #         response_list.append(js)

    #     return response_list


    # def run_client(self, q):
    #     j = 0
    #     while True:
    #         if j == 0:
    #             response = self.check_for_updates()
    #             j = 1
    #         else:
    #             prompts_list = []
    #             index_to_promptid = {}
    #             embeddings_only = []
    #             for i, prompt in enumerate(response):
    #                 text = prompt['raw']  # assuming text is string literal
    #                 promptid = prompt['id']
    #                 embeddings = torch.tensor(prompt['encoded']) # 1x512
                    
    #                 prompts_list.append(text)

    #                 embeddings_only.append(embeddings)
    #                 index_to_promptid[i] = promptid

    #             stacked = torch.stack([t.squeeze(0) for t in embeddings_only])
    #             q.put((prompts_list, stacked.unsqueeze(0), index_to_promptid))
    #         time.sleep(1)